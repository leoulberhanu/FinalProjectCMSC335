const express = require("express");   /* Accessing express module */
const http = require('http');
const fs = require('fs');
const console = require("console");
const path = require('path');
const { json } = require("express/lib/response");
const bodyParser = require("body-parser");



const app = express();  /* app is a request handler function */

app.set("views", path.resolve(__dirname, "templates"));
app.set("view engine", "ejs"); 
app.use(bodyParser.urlencoded({extended:false}));



require("dotenv").config({ path: path.resolve(__dirname, 'credentialsDontPost/.env') }) 

const userName = process.env.MONGO_DB_USERNAME;
const password = process.env.MONGO_DB_PASSWORD;

/* Our database and collection */
const databaseAndCollection = {db: "CMSC335DB", collection:"finalProject"};


/****** DO NOT MODIFY FROM THIS POINT ONE ******/
const { MongoClient, ServerApiVersion } = require('mongodb');
const { query } = require("express");

const uri = "mongodb+srv://leoulberhanu1:XOuneBXBifjIP8Bv@cluster0.0pjmv3d.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });




app.get("/", (req, res) => {
    res.render("index");
 });

app.get("/listing", (req,res)=>{
    res.render("listing");
});

app.post("/listing",async (req,res) =>{
    let distance = Number(req.body.distance);
    let price = Number(req.body.price);
    let item = {name: req.body.name, email: req.body.email, 
        distance: distance, style: req.body.style, price: price,
        size: req.body.size, additional: req.body.additional};

    await client.connect();
    await client.db(databaseAndCollection.db).collection(databaseAndCollection.collection).insertOne(item);


    const variables = {name: req.body.name, email: req.body.email};
    res.render("listingProcessed",variables);
});


app.get("/proximity", (req,res) =>{

    res.render("proximity");
});

app.post("/proximity", async (req,res) =>{
    let distance = Number(req.body.proximity);

    
    const filter = {distance: {$lte: distance}};
     let query1 = await client.db(databaseAndCollection.db)
     .collection(databaseAndCollection.collection)
     .find(filter).toArray();
    
     let table = `<table border=\"1\">`;
     table+=`<tr><th>name</th><th>email</th><th>price</th><th>proximity</th><th>style</th></tr>`;
     query1.forEach(p => table+=`<tr><td>${p.name}</td><td>${p.email}</td><td>${p.price}</td><td>${p.distance}</td><td>${p.style}</td></tr>`);
     table+=`</table>`;



    const variables = { table: table};
    res.render("proximityProcessed", variables);
});


app.get("/price", (req,res)=>{

    res.render("price");
});

app.post("/price", async(req,res) =>{

    let minPrice = Number(req.body.minPrice);
    let maxPrice = Number(req.body.maxPrice);


    
    const filter = {price: {$gte: minPrice, $lte: maxPrice}};
    let query1 = await client.db(databaseAndCollection.db)
     .collection(databaseAndCollection.collection)
     .find(filter).toArray();
    
     let table = `<table border=\"1\">`;
     table+=`<tr><th>name</th><th>email</th><th>price</th><th>proximity</th><th>style</th></tr>`;
     query1.forEach(p => table+=`<tr><td>${p.name}</td><td>${p.email}</td><td>${p.price}</td><td>${p.distance}</td><td>${p.style}</td></tr>`);
     table+=`</table>`;

    const variables ={table: table};
    res.render("priceProcessed", variables);
});



app.get("/style", (req,res)=>{

    res.render("style");
});

app.post("/style", async(req,res) =>{

    let style = req.body.style;

    
    const filter = {style: style};
    let query1 = await client.db(databaseAndCollection.db)
     .collection(databaseAndCollection.collection)
     .find(filter).toArray();
    
     let table = `<table border=\"1\">`;
     table+=`<tr><th>name</th><th>email</th><th>price</th><th>proximity</th><th>style</th></tr>`;
     query1.forEach(p => table+=`<tr><td>${p.name}</td><td>${p.email}</td><td>${p.price}</td><td>${p.distance}</td><td>${p.style}</td></tr>`);
     table+=`</table>`;

    const variables ={table: table};
    res.render("styleProcessed", variables);
});












const portNumber = 5001;

 app.listen(portNumber);

 process.stdin.setEncoding("utf8");
 process.stdout.write(`Web server started and running at: http://localhost:${portNumber}\n`);
 const prompt = "Stop to shutdown server: ";
 process.stdout.write(prompt);

 process.stdin.on("readable", function () {
    let dataInput = process.stdin.read();
    if (dataInput !== null) {
      let command = dataInput.trim();
      if (command === "Stop" || command ==="stop") {
        process.stdout.write("Shutting down the server\n");
        process.exit(1);
      } 
      process.stdout.write(prompt);
      process.stdin.resume();
    }
  });