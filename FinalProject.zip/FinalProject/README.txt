Team Members: Leoul B., Valine O., Stephane M.

App Description: SubleaseUMD.com is a central page where umd 
students can safely and easily find someone to sublease their space

API Links: 

Youtube Demo Link: 